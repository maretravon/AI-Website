const assistantButton = document.getElementById("ai-assistant");
const chatbox = document.getElementById("ai-chatbox");
const sendButton = document.getElementById("ai-send");
const inputField = document.getElementById("ai-input");
const messagesContainer = document.getElementById("ai-messages");

assistantButton.addEventListener("click", () => {
  chatbox.style.display = chatbox.style.display === "none" ? "flex" : "none";
});

sendButton.addEventListener("click", () => {
  const userMessage = inputField.value;
  if (userMessage) {
    const messageElement = document.createElement("div");
    messageElement.textContent = `You: ${userMessage}`;
    messagesContainer.appendChild(messageElement);
    inputField.value = "";
  }
});
